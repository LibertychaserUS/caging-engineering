# Decision Log

Record major decisions.

## Entry template

```text
Decision:
Reason:
Evidence:
Alternatives rejected:
Verifier / constraint impact:
Date:
```
