# Cage Expansion Requests

Use this when the current cage makes the goal unreachable.

## Request template

```text
Blocked goal:
Current boundary causing blockage:
Evidence of blockage:
Minimal requested expansion:
Risks:
Required approval:
Date:
```
