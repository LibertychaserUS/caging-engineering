# Final Trace

Summarize the final path after completion.

```text
Task:
Initial state:
Accepted path:
Verification evidence:
Failed paths compressed:
Memory updated:
Remaining risks:
```
