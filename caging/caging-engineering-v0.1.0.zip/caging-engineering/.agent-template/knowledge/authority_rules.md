# Authority Rules

Define source ranking and conflict resolution.

## Source priority

```text
1. [Highest authority]
2. [Second authority]
3. [Third authority]
4. [Low authority]
```

## Conflict resolution

```text
[Explain what happens when sources disagree]
```

## Version awareness

```text
[Record relevant versions, dates, or environments]
```
