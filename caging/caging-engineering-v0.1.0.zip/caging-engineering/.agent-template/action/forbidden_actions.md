# Forbidden Actions

List forbidden actions and semantic equivalents.

```text
[Forbidden action]
[Equivalent bypasses that are also forbidden]
```

Rules should apply to semantic effects, not only literal action names.
