# Risk Levels

Define action risk levels.

## Low risk

```text
[Safe actions]
```

## Medium risk

```text
[Actions requiring caution or additional verification]
```

## High risk

```text
[Actions requiring approval or cage expansion]
```
