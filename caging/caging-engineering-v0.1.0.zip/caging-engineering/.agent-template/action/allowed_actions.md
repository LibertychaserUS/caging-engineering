# Allowed Actions

List actions available under the current cage.

```text
[Action 1]
[Action 2]
[Action 3]
```

Include scope limits if needed.
