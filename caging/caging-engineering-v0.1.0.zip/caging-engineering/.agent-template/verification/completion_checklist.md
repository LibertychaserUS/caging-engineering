# Completion Checklist

Before declaring completion, verify:

```text
[ ] Goal is satisfied.
[ ] Hard constraints are preserved.
[ ] Required verifiers passed.
[ ] No forbidden actions were used.
[ ] Accepted path is recorded.
[ ] Failed paths are compressed if relevant.
[ ] No verifier or cage boundary was modified silently.
```
