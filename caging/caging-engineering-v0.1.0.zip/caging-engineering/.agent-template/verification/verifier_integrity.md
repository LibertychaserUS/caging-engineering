# Verifier Integrity

Protected verifiers and rules:

```text
[List protected tests, schemas, checklists, or external validators]
```

Modification policy:

```text
[Who may modify them and under what conditions]
```

Bypass detection notes:

```text
[Known bypass patterns]
```
