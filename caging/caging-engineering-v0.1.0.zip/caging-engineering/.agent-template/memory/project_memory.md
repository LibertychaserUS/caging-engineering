# Project Memory

Stable project-level memory.

## Architecture notes

```text
[Persistent notes]
```

## Known constraints

```text
[Persistent constraints]
```

## Known fragile areas

```text
[High-risk areas]
```
