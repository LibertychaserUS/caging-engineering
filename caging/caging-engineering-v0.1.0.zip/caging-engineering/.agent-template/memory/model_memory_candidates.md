# Model Memory Candidates

Patterns that may eventually deserve promotion into parametric memory or specialized knowledge models.

## Entry template

```text
Pattern:
Evidence:
Number of verified uses:
Risks if promoted:
Required review:
Date:
```

Do not treat this file as direct model memory. It is only a staging area.
