# Dormant Ideas

Ideas not currently adopted, but potentially useful later.

## Entry template

```text
Idea:
Why not adopted now:
Possible future trigger:
Date:
```
