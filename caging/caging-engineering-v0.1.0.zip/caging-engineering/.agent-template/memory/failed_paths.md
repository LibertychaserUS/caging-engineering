# Failed Path Index

Compressed records of failed paths.

## Entry template

```text
Attempt:
Why it failed:
Verifier evidence:
Do not repeat because:
Date:
```

Keep entries short. This is an index, not a full log archive.
