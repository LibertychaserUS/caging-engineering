# Task Memory

Current task-local memory.

## Current hypothesis

```text
[What the agent currently believes]
```

## Inspected sources/files

```text
[List inspected items]
```

## Current state

```text
[Summarize task progress]
```

## Next candidate action

```text
[Next action]
```
