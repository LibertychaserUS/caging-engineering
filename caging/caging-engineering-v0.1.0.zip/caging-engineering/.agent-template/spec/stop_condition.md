# Stop Condition

Define when the agent should stop.

Examples:

```text
All required verifiers passed.
No further change is needed.
Human approval is required.
The current cage makes the goal unreachable.
```
