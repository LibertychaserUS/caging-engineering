# Success Predicate

Define what must be true for the task to count as complete.

## Completion criteria

```text
[Criterion 1]
[Criterion 2]
[Criterion 3]
```

## Required verification

```text
[Tests, checks, validators, review steps]
```
