# Constraints

List all task constraints.

## Hard constraints

```text
[Must not be violated]
```

## Soft constraints

```text
[Preferences or lower-priority constraints]
```

## Unknown constraints

```text
[Clarify before execution if necessary]
```
