# Goal

Describe the task goal in a way that can become a target state.

## Raw user intent

```text
[Paste original task here]
```

## Structured goal

```text
[Define the desired final state]
```

## Notes

- Avoid vague verbs such as "improve" or "fix" without criteria.
- The goal should connect to a success predicate.
